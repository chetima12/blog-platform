--
-- PostgreSQL database dump
--

\restrict VF5KP1SCPXziuDIODp5vfaydbGrsegNerm8Zh1S4QEpihwTnlraAcu0bRJbfoSk

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: bloguser
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.posts OWNER TO bloguser;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: bloguser
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO bloguser;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bloguser
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: bloguser
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: bloguser
--

COPY public.posts (id, title, content, created_at) FROM stdin;
1	Welcome to Docker Blog!	This is your first post. Docker is amazing!	2026-07-14 22:22:44.789056
2	Multi-Container Apps	Using Docker Compose makes orchestration easy.	2026-07-14 22:22:44.789056
3	Caching with Redis	Redis helps make your app super fast!	2026-07-14 22:22:44.789056
\.


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bloguser
--

SELECT pg_catalog.setval('public.posts_id_seq', 33, true);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: bloguser
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict VF5KP1SCPXziuDIODp5vfaydbGrsegNerm8Zh1S4QEpihwTnlraAcu0bRJbfoSk

